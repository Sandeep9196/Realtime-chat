package main

type Message struct {
	ClientID string `json:"clientID"`
	Text     string  `json:"text"`
}
